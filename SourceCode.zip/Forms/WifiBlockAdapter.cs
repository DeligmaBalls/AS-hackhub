﻿using PcapDotNet.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PcapNet;

namespace Wifi_bulldozer.Forms
{
    public partial class WifiBlockAdapter : Form
    {
        private NetworkInterface[] nics;
        public static WifiBlockAdapter instance;
         private static IEnumerator nicsEnum;

        public NetworkInterface selectedNic;

        public bool packetsHaveToBeRedirected;
        public void CAdapter()
        {
           
            nics = NetworkInterface.GetAllNetworkInterfaces();
            
            packetsHaveToBeRedirected = false;
            
        }

        private void CAdapter_Load(object sender, EventArgs e)
        {

        }
        
        public  void WifiBlock2()
        {
           
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void WifiBlock_Load(object sender, EventArgs e)
        {
            IList<LivePacketDevice> allDevices = LivePacketDevice.AllLocalMachine;
            for (int i = 0; i != allDevices.Count(); ++i)
                DevicePrint(allDevices[i]);
            InitializeComponent();
      
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public static void DevicePrint(IPacketDevice device)

        {

          
            //Add Name
            Console.WriteLine(device.Name);
           
           
            //desc
            if (device.Description != null)
                Console.WriteLine("\tDescription: " + device.Description);

            //loopback
            Console.WriteLine("\tLoopback: " +
                              (((device.Attributes & DeviceAttributes.Loopback) == DeviceAttributes.Loopback)
                                   ? "yes"
                                   : "no"));
            //IP Address's
            foreach (DeviceAddress address in device.Addresses)
            {
                Console.WriteLine("\tAddress Family: " + address.Address.Family);

                if (address.Address != null)
                    Console.WriteLine(("\tAddress: " + address.Address));
                if (address.Netmask != null)
                    Console.WriteLine(("\tNetmask: " + address.Netmask));
                if (address.Broadcast != null)
                    Console.WriteLine(("\tBroadcast Address: " + address.Broadcast));
                if (address.Destination != null)
                    Console.WriteLine(("\tDestination Address: " + address.Destination));
            }
        }
        public void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (!(nicsEnum = nics.GetEnumerator()).MoveNext())
            {
                return;
            }
            NetworkInterface networkInterface;
            while (true)
            {
                networkInterface = (NetworkInterface)nicsEnum.Current;
                if (networkInterface.Description.CompareTo(comboBox1.SelectedItem.ToString()) == 0)
                {
                    break;
                }
                if (!nicsEnum.MoveNext())
                {
                    return;
                }
            }
            labelTypeText.Text = ((NetworkInterfaceType)(object)networkInterface.NetworkInterfaceType).ToString();
            int num = 0;
            if (0 < networkInterface.GetIPProperties().UnicastAddresses.Count)
            {
                do
                {
                    if (Convert.ToString(networkInterface.GetIPProperties().UnicastAddresses[num].Address.AddressFamily).EndsWith("V6"))
                    {
                        num++;
                        continue;
                    }
                    labelIpText.Text = networkInterface.GetIPProperties().UnicastAddresses[num].Address.ToString();
                    break;
                }
                while (num < networkInterface.GetIPProperties().UnicastAddresses.Count);
            }
            if (networkInterface.GetIPProperties().GatewayAddresses.Count > 0 && networkInterface.GetIPProperties().GatewayAddresses[0].Address.ToString().CompareTo("0.0.0.0") != 0)
            {
                labelGWText.Text = networkInterface.GetIPProperties().GatewayAddresses[0].Address.ToString();
                buttonOk.Enabled = true;
                selectedNic = networkInterface;
            }
            else
            {
                labelGWText.Text = "No Gateway !";
                buttonOk.Enabled = false;
            }
        }
        
           public WifiBlockAdapter()
        {

        }
            
        }

        
}
