﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Wifi_bulldozer.Forms
{
    public partial class Magic : Form
    {
        public Magic()
        {
            InitializeComponent();

            WifiBlockMain.instance.Enabled = false;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text.CompareTo("Quit") == 0)
            {
                ((IDisposable)WifiBlockMain.instance)?.Dispose();
            }
            else
            {
                if (File.Exists("license.txt"))
                {
                    File.Move("license.txt", "LicenseYouAccepted.txt");
                }
                WifiBlockMain.instance.Enabled = true;
                WifiBlockMain.instance.licenseAccepted();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
