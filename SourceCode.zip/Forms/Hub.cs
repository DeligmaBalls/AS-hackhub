﻿using SelfishNetv0;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wifi_bulldozer.Forms;


namespace Wifi_bulldozer
{
    public partial class Hub : Form
    {
        public Hub()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var WifiBlock2 = new ArpForm();
            WifiBlock2.Show();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Hub_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        public void AbrirFormulario<MiForm>(Func<MiForm> metodofactory) where MiForm : Form
        {
            Form formulario = panel1.Controls.OfType<MiForm>().FirstOrDefault();
            formulario = panel1.Controls.OfType<MiForm>().FirstOrDefault();//Busca en la colecion el formulario
            //si el formulario/instancia no existe
            if (formulario == null)
            {
                formulario = metodofactory();
                formulario.TopLevel = false;
                formulario.FormBorderStyle = FormBorderStyle.None;
                formulario.Dock = DockStyle.Fill;
                panel1.Controls.Add(formulario);
                panel1.Tag = formulario;
                formulario.Show();
                formulario.BringToFront();
               
            }
            //si el formulario/instancia existe
            else
            {
                formulario.BringToFront();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var Doxx2 = new DoxxTime();
            Doxx2.Show();
        }
    }
}
