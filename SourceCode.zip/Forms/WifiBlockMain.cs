﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AdvancedDataGridView;
using PcapNet;
using System.IO;
using System.Runtime.InteropServices;
using SelfishNetv0;

namespace Wifi_bulldozer.Forms
{
    public partial class WifiBlockMain : Form
    {
        public delegate void delegateOnNewPC(PC pc);

        public delegate void DelUpdateName(PC pc, string str);
        public Driver driver;
        public CArp cArp;
        public static WifiBlockMain instance;
        public WifiBlockMain()
        {
            InitializeComponent();
        }

        private unsafe void WifiBlockMain_Load(object sender, EventArgs e)
        {
            if ((IntPtr)this.driver.openDeviceDriver((sbyte*)(void*)Marshal.StringToHGlobalAnsi("npf")) == IntPtr.Zero)
            {
                if (System.IO.File.Exists("license.txt"))
                {
                    Magic cwizard = new Magic();
                    cwizard.Show((IWin32Window)this);
                    Decoder decoder = Encoding.UTF7.GetDecoder();
                    FileStream fileStream = System.IO.File.OpenRead("license.txt");
                    byte[] numArray = new byte[(int)fileStream.Length];
                    fileStream.Read(numArray, 0, (int)fileStream.Length);
                    char[] chars = new char[decoder.GetCharCount(numArray, 0, numArray.Length)];
                    decoder.GetChars(numArray, 0, numArray.Length, chars, 0);
                    cwizard.richTextBox1.Text = new string(chars);
                    fileStream.Close();
                }
                else
                    this.licenseAccepted();
            }
            else
            {
                int num = (int)MessageBox.Show("Driver WinPcap already installed");
            }
        }

        private void treeGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void timer3_Tick(object sender, EventArgs e)
        {

        }

        private void timer4_Tick(object sender, EventArgs e)
        {

        }

        private void timer5_Tick(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void toolStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void timer6_Tick(object sender, EventArgs e)
        {

        }
        public void licenseAccepted()
        {
            if (!this.driver.create())
            {
                int num = (int)MessageBox.Show("problem installing the drivers, do you have administrator privileges?");
                if (this == null)
                    return;
                this.Dispose();
            }
            else
            {
                WifiBlockAdapter cadapter = new WifiBlockAdapter();

                cadapter.Show((IWin32Window)this);
            }
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.cArp.startArpDiscovery();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (this.toolStripButton2.Checked)
                return;
            this.cArp.startRedirector();
            this.toolStripButton2.Checked = true;
            this.timer1.Interval = 1000;
            this.timer1.Start();
            this.timerSpoof.Start();
            this.timerSpoof.Interval = 2000;
            this.toolStripButton2.Checked = true;
            this.toolStripButton2.Enabled = false;
            this.timerDiscovery.Start();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (!this.toolStripButton2.Checked)
                return;
            this.cArp.stopRedirector();
            this.cArp.completeUnspoof();
            this.timer1.Stop();
            this.timerSpoof.Stop();
            int index = 0;
            if (0 < this.treeGridView1.Nodes[0].Nodes.Count)
            {
                do
                {
                    this.treeGridView1.Nodes[0].Nodes[index].Cells[3].Value = (object)string.Empty;
                    this.treeGridView1.Nodes[0].Nodes[index].Cells[4].Value = (object)string.Empty;
                    ++index;
                }
                while (index < this.treeGridView1.Nodes[0].Nodes.Count);
            }
            this.toolStripButton2.Checked = false;
            this.toolStripButton2.Enabled = true;
            this.timerDiscovery.Stop();
        }

        private void AddPc(PC pc)
        {
            if (pc.isGateway)
            {
                this.treeGridView1.Nodes[0].Cells[1].Value = (object)pc.ip.ToString();
                this.treeGridView1.Nodes[0].Cells[2].Value = (object)pc.mac.ToString();
                this.treeGridView1.Nodes[0].Cells[5].ReadOnly = true;
                this.treeGridView1.Nodes[0].Cells[6].ReadOnly = true;
                this.treeGridView1.Nodes[0].Cells[7].ReadOnly = true;
                this.treeGridView1.Nodes[0].Cells[8].ReadOnly = true;
                this.treeGridView1.Nodes[0].Cells[5].Value = (object)0;
                this.treeGridView1.Nodes[0].Cells[6].Value = (object)0;
                this.treeGridView1.Nodes[0].Cells[7].ReadOnly = true;
                this.treeGridView1.Nodes[0].Cells[8].ReadOnly = true;
            }
            else if (pc.isLocalPc)
            {
                TreeGridNode treeGridNode = this.treeGridView1.Nodes[0].Nodes.Add((object)"Your PC", (object)pc.ip, (object)pc.mac.ToString());
                treeGridNode.ImageIndex = 0;
                treeGridNode.Cells[5].Value = (object)0;
                treeGridNode.Cells[6].Value = (object)0;
                treeGridNode.Cells[5].ReadOnly = true;
                treeGridNode.Cells[6].ReadOnly = true;
                treeGridNode.Cells[7].Value = (object)false;
                treeGridNode.Cells[8].Value = (object)false;
                treeGridNode.Cells[7].ReadOnly = true;
                treeGridNode.Cells[8].ReadOnly = true;
            }
        }

        private void WifiBlockMain_Load_1(object sender, EventArgs e)
        {

        }
    }   
}


