﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wifi_bulldozer.Forms
{
    public partial class DoxxTime : Form
    {
        public String Doxx;
        public DoxxTime()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.whatismyip.net/" +   textBox1.Text );

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.whatismyip.com/" + textBox1.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://ipaddress.my/" + textBox1.Text);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();  
        }
    }
}
