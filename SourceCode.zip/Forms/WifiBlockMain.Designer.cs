﻿namespace Wifi_bulldozer.Forms
{
    partial class WifiBlockMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ColSpoof = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ColPCIP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColPCMac = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDownload = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColUpload = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColDownCap = new DataGridViewNumericUpDownElements.DataGridViewNumericUpDownColumn();
            this.ColUploadCap = new DataGridViewNumericUpDownElements.DataGridViewNumericUpDownColumn();
            this.ColPCName = new AdvancedDataGridView.TreeGridColumn();
            this.ColBlock = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.SuspendLayout();
            // 
            // ColSpoof
            // 
            this.ColSpoof.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColSpoof.HeaderText = "Spoof";
            this.ColSpoof.MinimumWidth = 35;
            this.ColSpoof.Name = "ColSpoof";
            this.ColSpoof.Visible = false;
            // 
            // ColPCIP
            // 
            this.ColPCIP.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColPCIP.HeaderText = "IP";
            this.ColPCIP.MinimumWidth = 35;
            this.ColPCIP.Name = "ColPCIP";
            this.ColPCIP.ReadOnly = true;
            this.ColPCIP.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColPCMac
            // 
            this.ColPCMac.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColPCMac.HeaderText = "Mac";
            this.ColPCMac.MinimumWidth = 35;
            this.ColPCMac.Name = "ColPCMac";
            this.ColPCMac.ReadOnly = true;
            this.ColPCMac.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColDownload
            // 
            this.ColDownload.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColDownload.HeaderText = "Download KB/s";
            this.ColDownload.MinimumWidth = 20;
            this.ColDownload.Name = "ColDownload";
            this.ColDownload.ReadOnly = true;
            this.ColDownload.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColUpload
            // 
            this.ColUpload.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColUpload.HeaderText = "Upload KB/s";
            this.ColUpload.MinimumWidth = 20;
            this.ColUpload.Name = "ColUpload";
            this.ColUpload.ReadOnly = true;
            this.ColUpload.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColDownCap
            // 
            this.ColDownCap.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColDownCap.HeaderText = "DownCap";
            this.ColDownCap.MinimumWidth = 35;
            this.ColDownCap.Name = "ColDownCap";
            this.ColDownCap.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ColUploadCap
            // 
            this.ColUploadCap.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColUploadCap.HeaderText = "UploadCap";
            this.ColUploadCap.MinimumWidth = 35;
            this.ColUploadCap.Name = "ColUploadCap";
            this.ColUploadCap.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ColPCName
            // 
            this.ColPCName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColPCName.DefaultNodeImage = null;
            this.ColPCName.FillWeight = 200F;
            this.ColPCName.HeaderText = "PC Name";
            this.ColPCName.MinimumWidth = 40;
            this.ColPCName.Name = "ColPCName";
            this.ColPCName.ReadOnly = true;
            this.ColPCName.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ColBlock
            // 
            this.ColBlock.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ColBlock.HeaderText = "Block";
            this.ColBlock.MinimumWidth = 35;
            this.ColBlock.Name = "ColBlock";
            // 
            // WifiBlockMain
            // 
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(1170, 563);
            this.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WifiBlockMain";
            this.Load += new System.EventHandler(this.WifiBlockMain_Load_1);
            this.ResumeLayout(false);

        }

        #endregion

        private AdvancedDataGridView.TreeGridView treeGridView1;
        private System.Windows.Forms.ContextMenuStrip ContextMenuViews;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuIP;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuMAC;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuDownload;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuUpload;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuDownloadCap;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuUploadCap;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuBlock;
        private System.Windows.Forms.ToolStripMenuItem ViewMenuSpoof;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timerSpoof;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timerDiscovery;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private AdvancedDataGridView.TreeGridView treeGridView2;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.ContextMenuStrip SelfishNetTray;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.NotifyIcon SelfishNetTrayIcon;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColSpoof;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColPCIP;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColPCMac;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColDownload;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColUpload;
        private DataGridViewNumericUpDownElements.DataGridViewNumericUpDownColumn ColDownCap;
        private DataGridViewNumericUpDownElements.DataGridViewNumericUpDownColumn ColUploadCap;
        private AdvancedDataGridView.TreeGridColumn ColPCName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColBlock;
    }
}