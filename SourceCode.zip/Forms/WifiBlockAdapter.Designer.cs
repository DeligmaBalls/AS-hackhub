﻿namespace Wifi_bulldozer.Forms
{
    partial class WifiBlockAdapter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelIpText = new System.Windows.Forms.Label();
            this.labelGWText = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelTypeText = new System.Windows.Forms.Label();
            this.labelRedirectInfo = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.buttonOk = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MV Boli", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(287, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 52);
            this.label1.TabIndex = 0;
            this.label1.Text = "WifiBlock";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(775, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "x";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Coral;
            this.label5.Location = new System.Drawing.Point(119, 241);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 16);
            this.label5.TabIndex = 24;
            this.label5.Text = "Ip Address :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Coral;
            this.label3.Location = new System.Drawing.Point(127, 272);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 25;
            this.label3.Text = "Gateway :";
            // 
            // labelIpText
            // 
            this.labelIpText.AutoSize = true;
            this.labelIpText.BackColor = System.Drawing.Color.Coral;
            this.labelIpText.Location = new System.Drawing.Point(219, 241);
            this.labelIpText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelIpText.Name = "labelIpText";
            this.labelIpText.Size = new System.Drawing.Size(44, 16);
            this.labelIpText.TabIndex = 26;
            this.labelIpText.Text = "0.0.0.0";
            // 
            // labelGWText
            // 
            this.labelGWText.AutoSize = true;
            this.labelGWText.BackColor = System.Drawing.Color.Coral;
            this.labelGWText.Location = new System.Drawing.Point(219, 272);
            this.labelGWText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelGWText.Name = "labelGWText";
            this.labelGWText.Size = new System.Drawing.Size(44, 16);
            this.labelGWText.TabIndex = 27;
            this.labelGWText.Text = "0.0.0.0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Coral;
            this.label4.Location = new System.Drawing.Point(127, 215);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 16);
            this.label4.TabIndex = 28;
            this.label4.Text = "NIC Type :";
            // 
            // labelTypeText
            // 
            this.labelTypeText.AutoSize = true;
            this.labelTypeText.BackColor = System.Drawing.Color.Coral;
            this.labelTypeText.Location = new System.Drawing.Point(219, 215);
            this.labelTypeText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTypeText.Name = "labelTypeText";
            this.labelTypeText.Size = new System.Drawing.Size(56, 16);
            this.labelTypeText.TabIndex = 29;
            this.labelTypeText.Text = "Ethernet";
            // 
            // labelRedirectInfo
            // 
            this.labelRedirectInfo.AutoEllipsis = true;
            this.labelRedirectInfo.AutoSize = true;
            this.labelRedirectInfo.BackColor = System.Drawing.Color.Coral;
            this.labelRedirectInfo.Location = new System.Drawing.Point(154, 319);
            this.labelRedirectInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelRedirectInfo.Name = "labelRedirectInfo";
            this.labelRedirectInfo.Size = new System.Drawing.Size(476, 16);
            this.labelRedirectInfo.TabIndex = 30;
            this.labelRedirectInfo.Text = "Windows does not redirect packet, however,internal redirection will be activated";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(157, 152);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(510, 24);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // buttonOk
            // 
            this.buttonOk.Location = new System.Drawing.Point(712, 400);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(75, 23);
            this.buttonOk.TabIndex = 31;
            this.buttonOk.Text = "Ok";
            this.buttonOk.UseVisualStyleBackColor = true;
            // 
            // WifiBlockAdapter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonOk);
            this.Controls.Add(this.labelRedirectInfo);
            this.Controls.Add(this.labelTypeText);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelGWText);
            this.Controls.Add(this.labelIpText);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WifiBlockAdapter";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.WifiBlock_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelIpText;
        private System.Windows.Forms.Label labelGWText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelTypeText;
        private System.Windows.Forms.Label labelRedirectInfo;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button buttonOk;
    }
}